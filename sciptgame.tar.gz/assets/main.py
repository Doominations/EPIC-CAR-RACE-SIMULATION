import asyncio
import math
import pygame

pygame.init()
pygame.mixer.init()

clock = pygame.time.Clock()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("EPIC CAR RACE SIMULATION")

# Load sounds ---------------------------------
try:
  countdown_sound = pygame.mixer.Sound("Sounds/Countdown.ogg")
except Exception as e:
  print(f"Error loading Countdown sound: {e}")

place_sounds = {}
for i in range(1, 6):
  try:
    place_sounds[i] = pygame.mixer.Sound(f"Sounds/PLACE{i}.ogg")
  except Exception as e:
    print(f"Error loading PLACE{i} sound: {e}")

# Load new finished sounds
try:
  time_finished_1st_sound = pygame.mixer.Sound("Sounds/TIMEFINISHED1ST.ogg")
except Exception as e:
  print(f"Error loading TIMEFINISHED1ST sound: {e}")

try:
  time_finished_not_1st_sound = pygame.mixer.Sound(
      "Sounds/TIMEFINISHNOT1ST.ogg"
  )
except Exception as e:
  print(f"Error loading TIMEFINISHNOT1ST sound: {e}")

# Load images ---------------------------------
maincar_sprite = pygame.image.load("Sprites/maincar.png").convert_alpha()
yellowcar_sprite = pygame.image.load("Sprites/yellowcar.png").convert_alpha()
greencar_sprite = pygame.image.load("Sprites/greencar.png").convert_alpha()
bluecar_sprite = pygame.image.load("Sprites/bluecar.png").convert_alpha()
pinkcar_sprite = pygame.image.load("Sprites/pinkcar.png").convert_alpha()

road_sprite = pygame.image.load("Sprites/road.png").convert_alpha()
flag_sprite = pygame.image.load("Sprites/FLAG.png").convert_alpha()

# Load custom UI Sprites ----------------------
menu_bg = pygame.image.load("UI/MENU.png").convert_alpha()
start_button_sprite = pygame.image.load("UI/startbutton.png").convert_alpha()
bottom_left_ui = pygame.image.load("UI/bottomleftui.png").convert_alpha()
bottom_right_ui = pygame.image.load("UI/bottomrightui.png").convert_alpha()
times_up_ui = pygame.image.load("UI/timesupui.png").convert_alpha()
run_button_sprite = pygame.image.load(
    "UI/runsimulationbutton.png"
).convert_alpha()
restart_button_sprite = pygame.image.load(
    "UI/restartbutton.png"
).convert_alpha()
directions_sprite = pygame.image.load("UI/directions.png").convert_alpha()

# Load Countdown UI Sprites (3, 2, 1, GO)
countdown_sprites = {
    3: pygame.image.load("UI/THREE.png").convert_alpha(),
    2: pygame.image.load("UI/TWO.png").convert_alpha(),
    1: pygame.image.load("UI/ONE.png").convert_alpha(),
    "GO": pygame.image.load("UI/GO.png").convert_alpha(),
}

# Load live place icons (1st to 5th)
place_icons = {
    1: pygame.image.load("UI/1.png").convert_alpha(),
    2: pygame.image.load("UI/2.png").convert_alpha(),
    3: pygame.image.load("UI/3.png").convert_alpha(),
    4: pygame.image.load("UI/4.png").convert_alpha(),
    5: pygame.image.load("UI/5.png").convert_alpha(),
}

# Scale UI elements
menu_bg = pygame.transform.scale(menu_bg, (WIDTH, HEIGHT))
start_button_sprite = pygame.transform.scale(start_button_sprite, (220, 55))
bottom_left_ui = pygame.transform.scale(bottom_left_ui, (380, 185))
bottom_right_ui = pygame.transform.scale(bottom_right_ui, (350, 185))
times_up_ui = pygame.transform.scale(times_up_ui, (440, 230))
run_button_sprite = pygame.transform.scale(run_button_sprite, (200, 50))
restart_button_sprite = pygame.transform.scale(
    restart_button_sprite, (220, 44)
)
directions_base_sprite = pygame.transform.scale(directions_sprite, (450, 300))

# Scale countdown sprites to fill the screen
for key in countdown_sprites:
  countdown_sprites[key] = pygame.transform.scale(
      countdown_sprites[key], (WIDTH, HEIGHT)
  )

# Scale place icons to 250x250
for key in place_icons:
  place_icons[key] = pygame.transform.scale(place_icons[key], (250, 250))

# Scale up the road sprite
road_scale = 12
road_sprite = pygame.transform.scale(
    road_sprite,
    (
        road_sprite.get_width() * road_scale,
        road_sprite.get_height() * road_scale,
    ),
)
road_width = road_sprite.get_width()

# Scale flag sprite
flag_sprite = pygame.transform.scale(flag_sprite, (225, 225))

# Camera & Track settings
car_screen_x = 200  # Main car's fixed screen X position (Camera anchor)
PIXELS_PER_METER = 40

# Setup retro/pixel-styled fonts
font = pygame.font.SysFont("Verdana", 14, bold=True)
bold_font = pygame.font.SysFont("Verdana", 16, bold=True)
title_font = pygame.font.SysFont("Verdana", 20, bold=True)

# UI Buttons Rectangles
start_button_rect = pygame.Rect(WIDTH // 2 - 110, HEIGHT // 2 + 100, 220, 55)
accel_plus_rect = pygame.Rect(315, 410, 30, 24)
accel_minus_rect = pygame.Rect(350, 410, 30, 24)

time_plus_rect = pygame.Rect(315, 445, 30, 24)
time_minus_rect = pygame.Rect(350, 445, 30, 24)

v0_plus_rect = pygame.Rect(315, 480, 30, 24)
v0_minus_rect = pygame.Rect(350, 480, 30, 24)

run_button_rect = pygame.Rect(20 + (380 - 200) // 2, 520, 200, 50)
restart_button_rect = pygame.Rect(WIDTH // 2 - 110, HEIGHT // 2 + 55, 220, 44)


async def main():
  # Simulation Time Tracking & Timers
  simulation_time = 0.0
  transition_timer = 0.0
  countdown_timer = 0.0

  # Rank Animation & Flash Tracking Variables
  prev_main_car_rank = 1
  rank_anim_timer = 0.0
  RANK_ANIM_DURATION = 0.3

  rank_flash_timer = 0.0
  RANK_FLASH_DURATION = 0.3

  finished_flash_timer = 0.0
  go_flash_triggered = False
  finished_sound_played = False

  # --- CAR DATA STRUCTURE (5 Cars) ---
  cars = [
      {
          "name": "Main Car",
          "sprite": maincar_sprite,
          "accel": 2.0,
          "target_time": 10.0,
          "v0": 0.0,
          "v": 0.0,
          "disp": 0.0,
          "y": 50,
      },
      {
          "name": "Yellow Car",
          "sprite": yellowcar_sprite,
          "accel": 1,
          "target_time": 10.0,
          "v0": 60.0,
          "v": 0.0,
          "disp": 0.0,
          "y": 120,
      },
      {
          "name": "Green Car",
          "sprite": greencar_sprite,
          "accel": 10,
          "target_time": 10.0,
          "v0": 35.0,
          "v": 0.0,
          "disp": 0.0,
          "y": 190,
      },
      {
          "name": "Blue Car",
          "sprite": bluecar_sprite,
          "accel": 0,
          "target_time": 10.0,
          "v0": 75.0,
          "v": 0.0,
          "disp": 0.0,
          "y": 260,
      },
      {
          "name": "Pink Car",
          "sprite": pinkcar_sprite,
          "accel": 21.5,
          "target_time": 10.0,
          "v0": 0,
          "v": 0.0,
          "disp": 0.0,
          "y": 330,
      },
  ]

  game_state = "MENU"
  run = True

  while run:
    dt = clock.tick(60) / 1000.0

    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        run = False

      elif event.type == pygame.MOUSEBUTTONDOWN:
        mouse_pos = event.pos

        # --- CONTROLS IN MENU STATE ---
        if game_state == "MENU":
          if start_button_rect.collidepoint(mouse_pos):
            try:
              click_sound = pygame.mixer.Sound("Sounds/ClickStart.ogg")
              click_sound.play()
            except Exception as e:
              print(f"Error playing ClickStart sound: {e}")
            game_state = "TRANSITION"
            transition_timer = 2.0

        # --- CONTROLS IN SETUP STATE ---
        elif game_state == "SETUP":
          if accel_plus_rect.collidepoint(mouse_pos):
            cars[0]["accel"] = round(min(15.0, cars[0]["accel"] + 1), 1)
          elif accel_minus_rect.collidepoint(mouse_pos):
            cars[0]["accel"] = round(max(0.0, cars[0]["accel"] - 1), 1)
          elif time_plus_rect.collidepoint(mouse_pos):
            cars[0]["target_time"] = round(
                min(30.0, cars[0]["target_time"] + 1.0), 1
            )
          elif time_minus_rect.collidepoint(mouse_pos):
            cars[0]["target_time"] = round(
                max(1.0, cars[0]["target_time"] - 1.0), 1
            )
          elif v0_plus_rect.collidepoint(mouse_pos):
            cars[0]["v0"] = round(min(25.0, cars[0]["v0"] + 1.0), 1)
          elif v0_minus_rect.collidepoint(mouse_pos):
            cars[0]["v0"] = round(max(0.0, cars[0]["v0"] - 1.0), 1)
          elif run_button_rect.collidepoint(mouse_pos):
            game_state = "COUNTDOWN"
            countdown_timer = 4.0
            simulation_time = 0.0
            prev_main_car_rank = 1
            go_flash_triggered = False
            finished_sound_played = False

            try:
              countdown_sound.play()
            except Exception as e:
              print(f"Error playing Countdown sound: {e}")

            for car in cars:
              car["target_time"] = cars[0]["target_time"]
              car["v"] = car["v0"]
              car["disp"] = 0.0

        # --- CONTROLS IN FINISHED STATE ---
        elif game_state == "FINISHED":
          if restart_button_rect.collidepoint(mouse_pos):
            game_state = "SETUP"
            simulation_time = 0.0
            prev_main_car_rank = 1
            go_flash_triggered = False
            finished_sound_played = False
            for car in cars:
              car["v"] = 0.0
              car["disp"] = 0.0

    # --- STATES & TIMERS ---
    if game_state == "TRANSITION":
      transition_timer -= dt
      if transition_timer <= 1.0 and not pygame.mixer.music.get_busy():
        try:
          pygame.mixer.music.load("Sounds/SONG.ogg")
          pygame.mixer.music.play(-1)
        except Exception as e:
          print(f"Error playing SONG background music: {e}")

      if transition_timer <= 0:
        game_state = "SETUP"

    elif game_state == "COUNTDOWN":
      countdown_timer -= dt
      if countdown_timer <= 1.0 and not go_flash_triggered:
        finished_flash_timer = 0.3
        go_flash_triggered = True

      if countdown_timer <= 0:
        game_state = "RUNNING"

    elif game_state == "RUNNING":
      simulation_time += dt
      for car in cars:
        car["v"] += car["accel"] * dt
        car["disp"] += car["v"] * dt

      if simulation_time >= cars[0]["target_time"]:
        game_state = "FINISHED"
        finished_flash_timer = 0.3
        simulation_time = cars[0]["target_time"]
        for car in cars:
          car["v"] = car["v0"] + (car["accel"] * simulation_time)

    if rank_anim_timer > 0:
      rank_anim_timer -= dt

    if rank_flash_timer > 0:
      rank_flash_timer -= dt

    if finished_flash_timer > 0:
      finished_flash_timer -= dt

    # --- DRAWING EVERYTHING ---
    if game_state == "MENU":
      screen.blit(menu_bg, (0, 0))
      screen.blit(start_button_sprite, start_button_rect.topleft)

    else:
      screen.fill((151, 210, 88))

      main_disp = cars[0]["disp"]
      master_road_offset = (main_disp * PIXELS_PER_METER) % road_width

      for car in cars:
        road_y = car["y"] - 20

        for i in range(-1, WIDTH // road_width + 2):
          stripe_x = (i * road_width) - int(
              master_road_offset
              if game_state in ["RUNNING", "FINISHED"]
              else 0
          )
          screen.blit(road_sprite, (stripe_x, road_y))

      for car in cars:
        if car["name"] == "Main Car":
          car_x = car_screen_x
        else:
          car_x = car_screen_x + (car["disp"] - main_disp) * PIXELS_PER_METER

        car_rect = car["sprite"].get_rect(center=(car_x, car["y"] + 10))
        screen.blit(car["sprite"], car_rect)

      # --- BOTTOM LEFT PANEL ---
      setup_panel_rect = pygame.Rect(20, 395, 380, 185)
      screen.blit(bottom_left_ui, setup_panel_rect.topleft)

      if game_state in ["SETUP", "TRANSITION"]:
        accel_label = font.render(
            f"Acceleration (a): {cars[0]['accel']:.1f} m/s^2",
            True,
            (30, 30, 30),
        )
        time_label = font.render(
            f"Time Limit (t): {cars[0]['target_time']:.1f} s",
            True,
            (30, 30, 30),
        )
        v0_label = font.render(
            f"Initial Velocity (vi): {cars[0]['v0']:.1f} m/s",
            True,
            (30, 30, 30),
        )

        screen.blit(accel_label, (35, 414))
        screen.blit(time_label, (35, 449))
        screen.blit(v0_label, (35, 484))

        btn_bg_color = (30, 60, 120)
        btn_text_color = (255, 255, 255)

        pygame.draw.rect(screen, btn_bg_color, accel_plus_rect, border_radius=4)
        pygame.draw.rect(
            screen, btn_bg_color, accel_minus_rect, border_radius=4
        )
        screen.blit(
            bold_font.render("+", True, btn_text_color),
            (accel_plus_rect.x + 8, accel_plus_rect.y + 1),
        )
        screen.blit(
            bold_font.render("-", True, btn_text_color),
            (accel_minus_rect.x + 10, accel_minus_rect.y + 1),
        )

        pygame.draw.rect(screen, btn_bg_color, time_plus_rect, border_radius=4)
        pygame.draw.rect(screen, btn_bg_color, time_minus_rect, border_radius=4)
        screen.blit(
            bold_font.render("+", True, btn_text_color),
            (time_plus_rect.x + 8, time_plus_rect.y + 1),
        )
        screen.blit(
            bold_font.render("-", True, btn_text_color),
            (time_minus_rect.x + 10, time_minus_rect.y + 1),
        )

        pygame.draw.rect(screen, btn_bg_color, v0_plus_rect, border_radius=4)
        pygame.draw.rect(screen, btn_bg_color, v0_minus_rect, border_radius=4)
        screen.blit(
            bold_font.render("+", True, btn_text_color),
            (v0_plus_rect.x + 8, v0_plus_rect.y + 1),
        )
        screen.blit(
            bold_font.render("-", True, btn_text_color),
            (v0_minus_rect.x + 10, v0_minus_rect.y + 1),
        )

        screen.blit(run_button_sprite, run_button_rect.topleft)

        breath_scale = 1.0 + 0.05 * math.sin(
            pygame.time.get_ticks() * 0.0025
        )
        dir_w = int(450 * breath_scale)
        dir_h = int(300 * breath_scale)

        animated_directions = pygame.transform.scale(
            directions_base_sprite, (dir_w, dir_h)
        )
        dir_rect = animated_directions.get_rect(topright=(WIDTH - 15, 15))
        screen.blit(animated_directions, dir_rect.topleft)

      elif game_state in ["COUNTDOWN", "RUNNING", "FINISHED"]:
        sorted_cars = sorted(cars, key=lambda c: c["disp"], reverse=True)
        main_car_rank = 1
        for idx, c in enumerate(sorted_cars):
          if c["name"] == "Main Car":
            main_car_rank = idx + 1
            break

        if main_car_rank != prev_main_car_rank:
          rank_anim_timer = RANK_ANIM_DURATION
          rank_flash_timer = RANK_FLASH_DURATION
          prev_main_car_rank = main_car_rank
          if main_car_rank in place_sounds:
            try:
              place_sounds[main_car_rank].play()
            except Exception as e:
              print(f"Error playing PLACE{main_car_rank} sound: {e}")

        icon = place_icons.get(main_car_rank, place_icons[1])

        if rank_anim_timer > 0:
          progress = 1.0 - (rank_anim_timer / RANK_ANIM_DURATION)
          scale = 0.7 + 0.3 * (1.0 - (1.0 - progress) ** 2)
        else:
          scale = 1.0

        orig_w, orig_h = icon.get_size()
        scaled_w = int(orig_w * scale)
        scaled_h = int(orig_h * scale)
        scaled_icon = pygame.transform.scale(icon, (scaled_w, scaled_h))

        icon_rect = scaled_icon.get_rect(
            center=(
                setup_panel_rect.x + setup_panel_rect.width // 2,
                setup_panel_rect.y + setup_panel_rect.height // 2,
            )
        )
        screen.blit(scaled_icon, icon_rect.topleft)

      # --- TELEMETRY READOUTS PANEL (Bottom Right) ---
      panel_rect = pygame.Rect(430, 395, 350, 185)
      screen.blit(bottom_right_ui, panel_rect.topleft)

      main_car = cars[0]

      texts = [
          f"Acceleration (a): {main_car['accel']:.1f} m/s^2",
          f"Time Elapsed (t): {simulation_time:.1f} / {main_car['target_time']:.1f} s",
          f"Initial Velocity (vi): {main_car['v0']:.1f} m/s",
          f"Final Velocity (vf): {main_car['v']:.1f} m/s",
          f"Displacement (d): {main_car['disp']:.1f} m",
      ]

      for index, text in enumerate(texts):
        text_surface = font.render(text, True, (30, 30, 30))
        screen.blit(
            text_surface, (panel_rect.x + 15, panel_rect.y + 18 + (index * 28))
        )

      # --- TRANSITION OVERLAY ---
      if game_state == "TRANSITION":
        if transition_timer > 1.0:
          fade_alpha = 255
        else:
          fade_alpha = int((transition_timer / 1.0) * 255)

        fade_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        fade_surface.fill((0, 0, 0, fade_alpha))
        screen.blit(fade_surface, (0, 0))

      # --- COUNTDOWN OVERLAY ---
      if game_state == "COUNTDOWN":
        if countdown_timer > 3.0:
          base_img = countdown_sprites[3]
          sub_time = countdown_timer - 3.0
        elif countdown_timer > 2.0:
          base_img = countdown_sprites[2]
          sub_time = countdown_timer - 2.0
        elif countdown_timer > 1.0:
          base_img = countdown_sprites[1]
          sub_time = countdown_timer - 1.0
        else:
          base_img = countdown_sprites["GO"]
          sub_time = countdown_timer

        if sub_time > 0.5:
          scale = 1.0
          alpha_val = 255
        else:
          sub_progress = (0.5 - sub_time) / 0.5
          scale = 1.0 + (sub_progress * 0.4)
          alpha_val = int((sub_time / 0.5) * 255)

        orig_w, orig_h = base_img.get_size()
        new_w = int(orig_w * scale)
        new_h = int(orig_h * scale)
        scaled_img = pygame.transform.scale(base_img, (new_w, new_h))
        img_rect = scaled_img.get_rect(center=(WIDTH // 2, HEIGHT // 2))

        faded_img = scaled_img.copy()
        faded_img.fill(
            (255, 255, 255, alpha_val), special_flags=pygame.BLEND_RGBA_MULT
        )
        screen.blit(faded_img, img_rect.topleft)

      # --- FINISHED STATE OVERLAY ---
      if game_state == "FINISHED":
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 100))
        screen.blit(overlay, (0, 0))

        modal_rect = pygame.Rect(
            WIDTH // 2 - 220, HEIGHT // 2 - 120, 440, 230
        )
        screen.blit(times_up_ui, modal_rect.topleft)

        sorted_cars = sorted(cars, key=lambda c: c["disp"], reverse=True)
        main_car_rank = 1
        for idx, c in enumerate(sorted_cars):
          if c["name"] == "Main Car":
            main_car_rank = idx + 1
            break

        if not finished_sound_played:
          try:
            if main_car_rank == 1:
              time_finished_1st_sound.play()
            else:
              time_finished_not_1st_sound.play()
          except Exception as e:
            print(f"Error playing finished sound: {e}")
          finished_sound_played = True

        if main_car_rank == 1:
          rank_str = "1st"
        elif main_car_rank == 2:
          rank_str = "2nd"
        elif main_car_rank == 3:
          rank_str = "3rd"
        elif main_car_rank == 4:
          rank_str = "4th"
        else:
          rank_str = "5th"

        place_surface = bold_font.render(
            f"Place: {rank_str}", True, (30, 30, 30)
        )
        disp_surface = font.render(
            f"Total Displacement: {main_car['disp']:.1f} m", True, (50, 50, 50)
        )
        vel_surface = font.render(
            f"Final Velocity (vf): {main_car['v']:.1f} m/s", True, (50, 50, 50)
        )

        screen.blit(place_surface, (modal_rect.x + 35, modal_rect.y + 80))
        screen.blit(disp_surface, (modal_rect.x + 35, modal_rect.y + 110))
        screen.blit(vel_surface, (modal_rect.x + 35, modal_rect.y + 140))

        screen.blit(restart_button_sprite, restart_button_rect.topleft)

      # --- WHITE FLASH OVERLAY ---
      if finished_flash_timer > 0:
        flash_alpha = int((finished_flash_timer / 0.3) * 255)
        flash_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        flash_surface.fill((255, 255, 255, flash_alpha))
        screen.blit(flash_surface, (0, 0))

      # --- RANK CHANGE FLASH OVERLAY ---
      if rank_flash_timer > 0:
        rank_flash_alpha = int(
            (rank_flash_timer / RANK_FLASH_DURATION) * 64
        )
        rank_flash_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        rank_flash_surface.fill((255, 255, 255, rank_flash_alpha))
        screen.blit(rank_flash_surface, (0, 0))

    pygame.display.flip()

    # CRITICAL: Yields control back to the browser canvas on every frame
    await asyncio.sleep(0)

  pygame.quit()


asyncio.run(main())